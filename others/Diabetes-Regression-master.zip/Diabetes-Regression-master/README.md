# Diabetes-Regression

data_preprocessing.ipynb是预处理+lgb训练+验证

lgb_result.ipynb是测试，生成result.csv目前得分0.87+，147名

tlblearn.py是开源的一段蛮逗比的代码，可以借鉴下sklearn的pipline如何使用，还有一些预处理PCA等

base1是另一段开源的代码，也是基于lgb的。瞄了一眼似乎用到了体检日期，目测分数要好于0.87+
